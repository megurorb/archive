# enumerable

Here are some exercise to learn to use `Enumerable` in a better way.

1. generate_hash

Implement three methods that generate a hash from array(s).

After passed the test, you should refactor both of implementation and test. Name of methods can be changed.

1. lunch_members

Implement `LunchMembers.shuffle` and refactor spec.

1. each_and_include

Rename and refactor `EachAndInclude.method_foo`.

Also spec should be refactored too.

4. tap_tap

Rename and refactor `TapTap.method_foo` and `TapTap.method_bar`.

Also spec should be refactored too.
