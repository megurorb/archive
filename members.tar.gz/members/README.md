# members

If you want to join Meguro.rb, see and do following steps.

1. fork megurorb/members into your account
1. add your info at members.yml
1. send a pull-request
