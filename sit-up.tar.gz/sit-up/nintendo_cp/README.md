# Nintendo Code Puzzle

[RubyKaigi2013](http://rubykaigi.org/2013)で配布された任天堂のフライヤーに、RubyのCode Puzzleが掲載されていました。練習問題としてちょうどいいので、Meguro.rbで挑戦してみましょう。

* [Code Puzzle](http://cp1.nintendo.co.jp/)
 * [Ruby 2013.5 "decode the answer"](http://cp1.nintendo.co.jp/ruby.html)
 * ![Original Image](http://cp1.nintendo.co.jp/img/ruby_main.jpg)

