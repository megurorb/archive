# -*- coding: utf-8 -*-
libs_dir = File.join(File.dirname(__FILE__), '..', 'lib')
require 'rspec'

require 'generate_hash'
require 'lunch_members'
require 'each_and_include'
require 'tap_tap'
