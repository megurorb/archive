# sit-up

## What is this?

This repository is for your training of coding.

There are some pretty bad codes. So, you can refactor these codes, and send pull-request to be reviewed

Refactoring and be reviewed is nice exercise to train your coding skill, I think. Try and train to be a good programmer.

## Usage

* fork this repository
* refactor codes
* commit, push and send a pull request
* PR will be reviewed

NOTE: your pull-request that you refactored will NOT be merged because these codes are examples for training.

## Need more examples

Meguro.rb wants more code examples for trainging. Please send pull-request with bad codes to be refactored or ideas of coding themes. These will be merged if effective for training.

Also need pull-request to these poor english... :dizzy_face:
